/*
 * Rajat Kuthiala
 * Homework 4 Part 6
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */import java.util.Scanner;

public class Part6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = "play";
		String y = "";
		while (!x.equals("stop")){
			System.out.println("Please enter Word(Insert stop at any time to end): ");
			Scanner words = new Scanner(System.in);
			x = words.nextLine();
			y = y+ " " +x;
				
		}
		System.out.println(y);
	}

}

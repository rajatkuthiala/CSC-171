/*
 * Rajat Kuthiala
 * Homework 4 Part 4
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
import java.util.Scanner;


public class Part4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the number: ");
		Scanner number = new Scanner(System.in);
		int y = number.nextInt();
		System.out.println("Countdown Begins");
		while(y>=0){
			System.out.println(y);
			y=y-1;
		}
		
		
		
		

	}

}

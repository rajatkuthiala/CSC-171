/*
 * Rajat Kuthiala
 * Homework 4 Part 3
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
public class Part3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=1;
		while (x<=100){
			System.out.println(x);
			x = x+3;
		}
	}

}

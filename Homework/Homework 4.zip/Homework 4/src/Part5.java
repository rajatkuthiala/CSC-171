/*
 * Rajat Kuthiala
 * Homework 4 Part 5
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
import java.util.Scanner;


public class Part5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y=1;
		int x = 0;
		while (y!=0){
			System.out.println("Please enter the number(Insert 0 at any time to get the sum): ");
			Scanner number = new Scanner(System.in);
			y= number.nextInt();
			x=x+y;
		
			
		}
		System.out.println("Sum of numbers is: "+x);
		

	}

}

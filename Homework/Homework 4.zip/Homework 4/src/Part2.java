/*
 * Rajat Kuthiala
 * Homework 4 Part 2
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
import java.util.Scanner;


public class Part2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the number: ");
		Scanner number = new Scanner(System.in);
		int y = number.nextInt();
		for (int i =0; i<11; i++ ) {
			System.out.println(i*y);
		
		}
		
		

	}

}

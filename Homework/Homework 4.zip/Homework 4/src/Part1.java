/*
 * Rajat Kuthiala
 * Homework 4 Part 1
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
import java.util.Scanner;


public class Part1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the number: ");
		Scanner number = new Scanner(System.in);
		int y = number.nextInt();
		int x=1;
		while (x < 11){
			System.out.println(x*y);
		x=x+1;
		}
		
		

	}

}



Lab 7

1) Did not quiet understand the question so added two methods to add mother &
   Father to the person.
2) Added new child method but couldnt figure out how to take that and make a new person.
3) Works well. First string can be sentence or word. 2 string has to be word.
4) Works fine 
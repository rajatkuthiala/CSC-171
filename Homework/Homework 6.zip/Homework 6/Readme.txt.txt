Lab 6

1) For first part i kept it simple as per the requirements.
2) 2nd part had the basic class with proper constructors and tester.
3) For this part I created a class with 3 constructors like name, type(bird or land),
   and number of species recorded. One method i implimented was to add number of species
   found.
4) Forth part runs according to specifications, but i couldnt figue out why it is rounding 
   the number.
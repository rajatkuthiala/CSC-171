/*
 * Rajat Kuthiala
 * Homework 6 Part 1
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */

class Person{
	String name;
	int age;
	String phone;
	
	public Person(String name, int age, String phone){
		this.name=name;
		this.age=age;
		this.phone=phone;
	}
	
}
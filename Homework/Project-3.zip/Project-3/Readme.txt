/*
 * Rajat Kuthiala
 * Project 3
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
  
                                                         $$$$      $$$$$$       $$$$       $$$      $$$$$$         
                                                         $$$$      $$$$$$$      $$$$      $$$$      $$$$$$$        
                                                         $$$$      $$$$$$$       $$$      $$$       $$$$$$$        
                                                         $$$$     $$$$$$$$       $$$$     $$$      $$$$$$$$        
                                                         $$$$     $$$  $$$$      $$$$    $$$$      $$$  $$$$       
                                                         $$$$    $$$$  $$$$       $$$    $$$      $$$$  $$$$       
                                                         $$$$    $$$    $$$$      $$$$   $$$      $$$    $$$$      
                                                         $$$$    $$$    $$$$       $$$  $$$$      $$$    $$$$      
                                                         $$$$   $$$$$$$$$$$$       $$$$ $$$      $$$$$$$$$$$$      
                                                         $$$$   $$$$$$$$$$$$$      $$$$$$$$      $$$$$$$$$$$$$     
                                                         $$$$  $$$$$$$$$$$$$$       $$$$$$$     $$$$$$$$$$$$$$     
                                                         $$$$  $$$$       $$$$      $$$$$$      $$$$       $$$$    
                                                         $$$$  $$$        $$$$      $$$$$$      $$$        $$$$    
                                                         $$$$ $$$$        $$$$       $$$$      $$$$        $$$$    
                                                         $$$$ $$$          $$$$      $$$$      $$$          $$$$   
                                                         $$$                                                       
                                                    $$$$$$$$                                                       
                                                   $$$$$$$                                                        
                                                 $$$$$$             

DISCRIPTION:

This is a text based Football Game which requires user to type commands to play the came and plan out their game.
The game follows all the Real football rules like kickoff and throwback.

CHALLENGES:

-The basic challenge while making this project that i faced was the lack of shapes i thought i could impliment in this program.
-Second challenge was the resizing of window, I did not know how to adjust my projectile according to window. Should i resize the projectile or leave it unscalled
 ,So I left it un resizable.

KNOWN BUGS:

-If you simulate the program without filling in speed and angle, it will throw expectedfield error.
-It will not resize when we enlarge window

DIRECTIONS:
1) Run the game
2) User inputs Projectile speed.
3) User enters Projectile angle.
4) User sets color using RBG Slider.
5) User select shape of explosion under shapes.
6) User clicks simulate.



CREDIT:

Rajat Kuthiala

REFERENCES:

LOGO FROM Google Text Art





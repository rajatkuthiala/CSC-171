/*
 * Rajat Kuthiala
 * Homework 3
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */


This lab has 4 Classes.
I named the classes as Parts (1-4)

1) I had a little confusion about the first part on whether the secret number was to be assgned or to be random. So i assigned it a specific value.
2) This part required us to tell the Type of number(=ve, -ve or zero)
3) Third part required us to take age as input and output message according to age group
4) This was a little tricky part. I was not sure for the part where we had to take answer for the hockey question so i just made answers either 1 or 2.
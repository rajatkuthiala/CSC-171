/*
 * Rajat Kuthiala
 * Homework 2
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */


This lab has 4 Classes.
I named the classes as Parts (1-4)

1) the first part performs basic arithmetic operations and displays the result.
2) Second Part converts given farhenhite temprature to kelvin
3) This part converts seconds to hours minutes seconds. It uses basic arithmatic operations.
4) fourth part calculates energy. We inout mass of object in the equation.
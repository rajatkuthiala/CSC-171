/*
 * Rajat Kuthiala
 * Project 4
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
  
                                                         $$$$      $$$$$$       $$$$       $$$      $$$$$$         
                                                         $$$$      $$$$$$$      $$$$      $$$$      $$$$$$$        
                                                         $$$$      $$$$$$$       $$$      $$$       $$$$$$$        
                                                         $$$$     $$$$$$$$       $$$$     $$$      $$$$$$$$        
                                                         $$$$     $$$  $$$$      $$$$    $$$$      $$$  $$$$       
                                                         $$$$    $$$$  $$$$       $$$    $$$      $$$$  $$$$       
                                                         $$$$    $$$    $$$$      $$$$   $$$      $$$    $$$$      
                                                         $$$$    $$$    $$$$       $$$  $$$$      $$$    $$$$      
                                                         $$$$   $$$$$$$$$$$$       $$$$ $$$      $$$$$$$$$$$$      
                                                         $$$$   $$$$$$$$$$$$$      $$$$$$$$      $$$$$$$$$$$$$     
                                                         $$$$  $$$$$$$$$$$$$$       $$$$$$$     $$$$$$$$$$$$$$     
                                                         $$$$  $$$$       $$$$      $$$$$$      $$$$       $$$$    
                                                         $$$$  $$$        $$$$      $$$$$$      $$$        $$$$    
                                                         $$$$ $$$$        $$$$       $$$$      $$$$        $$$$    
                                                         $$$$ $$$          $$$$      $$$$      $$$          $$$$   
                                                         $$$                                                       
                                                    $$$$$$$$                                                       
                                                   $$$$$$$                                                        
                                                 $$$$$$             

DISCRIPTION:

This program is a lob pong game.
Single Player Only
Game Starts as soon as you run it.
You start of with 5 lives.
After every 10 points the level increases which increases the speed of the ball.

CHALLENGES:

-I had to do a little research online to see how to impliment arrow keys to move the pong
-Second challenge was the resizing of window, every time i tried to impliment resizing, it messed up my bounce conditions.
- I just couldnt figyre out the projectile equations, so i left them.

KNOWN BUGS:

-The program does wait for user to get ready. It starts the game as soon as you run it.
-It does not resize

DIRECTIONS:
1) Run the game
2) Use left or right arrow to move pong 
3) Dont let the ball fall down.



CREDIT:

Rajat Kuthiala

REFERENCES:

LOGO FROM Google Text Art





/*
 * Rajat Kuthiala
 * Project 4
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */



import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.Timer;

import javax.swing.JFrame;


public class Gameplay extends Canvas{
	
	int ball_x,ball_y,speed_x,speed_y,ball_size;
	int pong_x, pong_y, pong_move ,pong_size;
	int score, lives;
	int level, level_score;
	int vx,vy,x,y;
	int time;
	Timer t = new Timer(true);

public Gameplay(){
	enableEvents(java.awt.AWTEvent.KEY_EVENT_MASK);
	setBackground(Color.BLACK);
	score=0;
	lives=5;
	
	ball_x = 300;
	ball_y = 200;
	speed_x = 2;
	speed_y = 6;
	ball_size=20;

	pong_x = 250;
	pong_y = 450;
	pong_move = 20;
	pong_size=200;
	
	level=1;
	level_score=0;
	
	time=360;

	
	t.schedule(new java.util.TimerTask()
	    {
	    public void run(){
	    	bounce();
	        repaint();
	        }
	    },0,20);
}

public void paint(Graphics g)
{
	g.setColor(Color.white);
	g.fillOval(ball_x,ball_y,20,20);
	
	g.setColor(Color.green);
	g.fillArc(500, 20, 50, 50, 0, time);
	
	g.setColor(Color.white);
	g.fillRect(pong_x,535, pong_size,10);
	
	g.setFont(new Font("Aerial", Font.PLAIN, 20));
	
	g.drawString("Score : " + score  ,10, 20);
	g.drawString("Lives : " + lives , 10, 40 );
	g.drawString("Level : " + level , 10, 60 );
}
public void processKeyEvent(KeyEvent e)
{
    if ( e.getID() == KeyEvent.KEY_PRESSED )
    {
        if ( e.getKeyCode() == KeyEvent.VK_RIGHT && pong_x<getWidth()-pong_size)
        {
        pong_x = pong_x + pong_move; 
        }

        if ( e.getKeyCode() == KeyEvent.VK_LEFT && pong_x>0 )
        {
        pong_x = pong_x - pong_move;
        }
    }
}
public void bounce()
	{
	
	
	
	ball_x = ball_x + speed_x;
	ball_y = ball_y + speed_y;
	
    if(level_score<10){
	if(ball_x<0 || ball_x>560){
    	speed_x=-speed_x;
    	
    }
    if((ball_y)>590&& (ball_x<pong_x||ball_x>pong_x+200)){
    	if(lives>0){
    		lives--;
    		ball_x=300;
    		ball_y=400;
    		pong_x = 250;
    		pong_y = 450;
    		
    	}
    	else{
    	System.out.println("Game Over");
    	t.cancel();
    	}
    }
    if(ball_y<0){
    	speed_y=-speed_y;
    }
    if(ball_y+20>535&& (ball_x>=pong_x&&ball_x<=pong_x+200)){
    	speed_y=-speed_y;
    	score++;
    	level_score++;
    	
    }
    else{
    	
    }
   }
    else{
    	level++;
    	speed_x=speed_x+1;
    	speed_y=speed_y+1;
    	level_score=0;
    }
}
public boolean isFocusable(){
	return true;							//Took Help From Google to implement it.
	}
public static void main(String[] args)
	{
	JFrame jf = new JFrame("Lob Pong");
	jf.setSize(600,600);
	jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	jf.add(new Gameplay());
	jf.setVisible(true);
}


}


/*
 * Rajat Kuthiala
 * Project 1
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
  
                                                         $$$$      $$$$$$       $$$$       $$$      $$$$$$         
                                                         $$$$      $$$$$$$      $$$$      $$$$      $$$$$$$        
                                                         $$$$      $$$$$$$       $$$      $$$       $$$$$$$        
                                                         $$$$     $$$$$$$$       $$$$     $$$      $$$$$$$$        
                                                         $$$$     $$$  $$$$      $$$$    $$$$      $$$  $$$$       
                                                         $$$$    $$$$  $$$$       $$$    $$$      $$$$  $$$$       
                                                         $$$$    $$$    $$$$      $$$$   $$$      $$$    $$$$      
                                                         $$$$    $$$    $$$$       $$$  $$$$      $$$    $$$$      
                                                         $$$$   $$$$$$$$$$$$       $$$$ $$$      $$$$$$$$$$$$      
                                                         $$$$   $$$$$$$$$$$$$      $$$$$$$$      $$$$$$$$$$$$$     
                                                         $$$$  $$$$$$$$$$$$$$       $$$$$$$     $$$$$$$$$$$$$$     
                                                         $$$$  $$$$       $$$$      $$$$$$      $$$$       $$$$    
                                                         $$$$  $$$        $$$$      $$$$$$      $$$        $$$$    
                                                         $$$$ $$$$        $$$$       $$$$      $$$$        $$$$    
                                                         $$$$ $$$          $$$$      $$$$      $$$          $$$$   
                                                         $$$                                                       
                                                    $$$$$$$$                                                       
                                                   $$$$$$$                                                        
                                                 $$$$$$             

DISCRIPTION:

This is a text based game in which user has to calculate speed and angle to shoot a projectile and hit a target.

DIRECTIONS:
1) Run the game
2) Initially the user is given 3 points out of which 1 is taken for a try.
3) Game will display the distance of target
4) User inputs speed in m/s(meters per second)
5) User enters angle in degrees.
6) Game will tell how accurate the projectile was.
7) Score conditions:
	-Less than 1m accuracy, +5 points
	-Within 1, and 3m, +1 pint
	-more than 3m, 0 points
8) User is given option to retry, pass the round or quit the game. 
   User can input his choice.
9)At the end of game, user is displayed his final score.

CREDIT:
Rajat Kuthiala

REFERENCES:
Looked up on google how to generate random number.
Looked up google for the implimentation of math function.

LOGO FROM Google Text Art





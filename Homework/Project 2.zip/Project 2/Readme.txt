/*
 * Rajat Kuthiala
 * Project 1
 * TR 11:05AM-12:20PM
 * TA: Becky Everson
 * 
 * I affirm that I have not given 
 * or received any unauthorized help 
 * on this assignment, and that this 
 * work is my own.
 */
  
                                                         $$$$      $$$$$$       $$$$       $$$      $$$$$$         
                                                         $$$$      $$$$$$$      $$$$      $$$$      $$$$$$$        
                                                         $$$$      $$$$$$$       $$$      $$$       $$$$$$$        
                                                         $$$$     $$$$$$$$       $$$$     $$$      $$$$$$$$        
                                                         $$$$     $$$  $$$$      $$$$    $$$$      $$$  $$$$       
                                                         $$$$    $$$$  $$$$       $$$    $$$      $$$$  $$$$       
                                                         $$$$    $$$    $$$$      $$$$   $$$      $$$    $$$$      
                                                         $$$$    $$$    $$$$       $$$  $$$$      $$$    $$$$      
                                                         $$$$   $$$$$$$$$$$$       $$$$ $$$      $$$$$$$$$$$$      
                                                         $$$$   $$$$$$$$$$$$$      $$$$$$$$      $$$$$$$$$$$$$     
                                                         $$$$  $$$$$$$$$$$$$$       $$$$$$$     $$$$$$$$$$$$$$     
                                                         $$$$  $$$$       $$$$      $$$$$$      $$$$       $$$$    
                                                         $$$$  $$$        $$$$      $$$$$$      $$$        $$$$    
                                                         $$$$ $$$$        $$$$       $$$$      $$$$        $$$$    
                                                         $$$$ $$$          $$$$      $$$$      $$$          $$$$   
                                                         $$$                                                       
                                                    $$$$$$$$                                                       
                                                   $$$$$$$                                                        
                                                 $$$$$$             

DISCRIPTION:

This is a text based Football Game which requires user to type commands to play the came and plan out their game.
The game follows all the Real football rules like kickoff and throwback.

CHALLENGES:

There vere many challenges while making this game. Firstly the lack of knowledge about the game was a big challenge in itself.
I could not properly impliment the Kick return - Pass and Kick return- down for the 4th down.
Secondly I could not understand the main objective of the game,(Scoring part). So it is bad a scoring.
Also the ball position might be a little buggy when your team is playing in defence. 

KNOWN BUGS:

Score tracker
Endzone distance tracking for when you are playing in defence
A little unoptimized code
Down Printer for user console(I was confused if we had to write the number of down a team was on)

DIRECTIONS:
1) Run the game
2) User inputs their Team name
3) User enters computer Team Name
4) User enters toss preference.
5) If user wins the toss he will be asked to choose to  kick or recieve. Otherwise computer will choose.
6) Depending on toss user will have to choose from defence choices and offence choices.


CREDIT:

Rajat Kuthiala

REFERENCES:

LOGO FROM Google Text Art




